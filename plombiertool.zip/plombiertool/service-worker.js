/* ===================== service-worker.js =====================
   Mise en cache des fichiers de l'application pour un fonctionnement
   hors ligne. Stratégie : "cache d'abord, puis réseau" pour les fichiers
   de l'app, avec repli sur le réseau pour tout le reste.

   ⚠️ Si tu modifies les fichiers de l'application, pense à changer
   CACHE_NAME (ex: 'plombiertool-v2') pour forcer la mise à jour du cache
   chez les utilisateurs.
*/

const CACHE_NAME = 'plombiertool-v1';

const FILES_TO_CACHE = [
  './',
  './index.html',
  './manifest.json',
  './css/style.css',
  './js/db.js',
  './js/app.js',
  './js/hydraulique.js',
  './js/chauffage.js',
  './js/mesures.js',
  './js/tubes.js',
  './js/devis.js',
  './js/checklist.js',
  './js/fiches.js',
  './js/settings.js',
  './icons/icon-192.png',
  './icons/icon-512.png'
];

// Installation : on met en cache tous les fichiers de l'application
self.addEventListener('install', (event) => {
  self.skipWaiting();
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => cache.addAll(FILES_TO_CACHE))
  );
});

// Activation : on supprime les anciens caches
self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((keys) =>
      Promise.all(keys.filter((k) => k !== CACHE_NAME).map((k) => caches.delete(k)))
    )
  );
  self.clients.claim();
});

// Interception des requêtes : cache d'abord, sinon réseau
self.addEventListener('fetch', (event) => {
  if (event.request.method !== 'GET') return;

  event.respondWith(
    caches.match(event.request).then((cached) => {
      if (cached) return cached;
      return fetch(event.request)
        .then((response) => {
          // On met aussi en cache les nouvelles ressources récupérées avec succès
          if (response && response.status === 200 && event.request.url.startsWith(self.location.origin)) {
            const clone = response.clone();
            caches.open(CACHE_NAME).then((cache) => cache.put(event.request, clone));
          }
          return response;
        })
        .catch(() => {
          // Hors ligne et pas en cache : on renvoie la page d'accueil pour éviter un écran blanc
          if (event.request.mode === 'navigate') {
            return caches.match('./index.html');
          }
        });
    })
  );
});
